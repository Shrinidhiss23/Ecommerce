package com.java.main;
import com.java.dao.*;
import com.java.entity.*;
import com.java.exceptions.*;
import java.util.*;
public class EcomApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessorRepository op = new OrderProcessorRepositoryImpl();
        
        while (true) {
            System.out.println("1. Register Customer");
            System.out.println("2. Create Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Add to Cart");
            System.out.println("5. View Cart");
            System.out.println("6. Place Order");
            System.out.println("7. View Customer Order");
            System.out.println("8. Exit");
            
            int ch = sc.nextInt();
            sc.nextLine();
            
            try {
                switch (ch) {
                    case 1:
                    	System.out.println("Enter Customer Id: ");
                        int customer_id = sc.nextInt();
                        System.out.println("Enter Customer Name: ");
                        sc.nextLine();
                        String name = sc.nextLine();
                        System.out.println("Enter Customer Email: ");
                        String email = sc.nextLine();
                        System.out.println("Enter Customer Password: ");
                        String password = sc.nextLine();
                        Customers customer = new Customers(name, email, password);
                        if (op.createCustomer(customer)) {
                            System.out.println("Customer registered!");
                        }
                        break;
                    case 2:
                    	 System.out.println("Enter Product id: ");
                         int productId = sc.nextInt();
                        System.out.println("Enter Product Name: ");
                        sc.nextLine();
                        String productName = sc.nextLine();
                        System.out.println("Enter Product Price: ");
                        double price = sc.nextDouble();
                        sc.nextLine();
                        System.out.println("Enter Product Description: ");
                        String description = sc.nextLine();
                        System.out.println("Enter Stock Quantity: ");
                        int stockQuantity = sc.nextInt();
                        sc.nextLine();
                        Products product = new Products(productName, price, description, stockQuantity);
                        if (op.createProduct(product)) {
                            System.out.println("Product created successfully!");
                        }
                        break;
                    case 3:
                        System.out.println("Enter Product ID to delete: ");
                        int  product_id = sc.nextInt();
                        if (op.deleteProduct(product_id)) {
                            System.out.println("Product deleted!");
                        }
                        break;
                    case 4:
                        System.out.println("Enter Customer ID: ");
                        int customerIdForCart = sc.nextInt();
                        System.out.println("Enter Product ID: ");
                        int productIdForCart = sc.nextInt();
                        System.out.println("Enter Quantity: ");
                        int quantity = sc.nextInt();
                        sc.nextLine(); 
                        Customers customerForCart = new Customers(customerIdForCart);
                        Products productForCart = new Products(productIdForCart);
                        if (op.addToCart(customerForCart, productForCart, quantity)) {
                            System.out.println("Product added to cart!");
                        }
                        break;
                    case 5:
                        System.out.println("Enter Customer ID: ");
                        int customerIdForViewCart = sc.nextInt();
                        sc.nextLine();
                        Customers customerForViewCart = new Customers(customerIdForViewCart);
                        List<Products> cartProducts = op.getAllFromCart(customerForViewCart);
                        System.out.println("Products in Cart: ");
                        for (Products p : cartProducts) {
                            System.out.println(p);
                        }
                        break;
                    case 6:
                        System.out.println("Enter Customer ID: ");
                        int customerIdForOrder = sc.nextInt();
                        sc.nextLine(); 
                        Customers customerForOrder = new Customers(customerIdForOrder);
                        List<Map<Products, Integer>> cartItems = new ArrayList<>();
                        System.out.println("Enter Shipping Address: ");
                        String shippingAddress = sc.nextLine();
                        if (op.placeOrder(customerForOrder, cartItems, shippingAddress)) {
                            System.out.println("Order placed!");
                        }
                        break;
                    case 7:
                        System.out.println("Enter Customer ID: ");
                        int customerIdForViewOrders = sc.nextInt();
                        sc.nextLine(); 
                        List<Orders> orders = op.getOrdersByCustomer(customerIdForViewOrders);
                        System.out.println("Your Orders: ");
                        for (Orders o : orders) {
                            System.out.println(o);
                        }
                        break;
                    case 8:
                        System.out.println("Exiting...");
                        System.exit(0);
                    default:
                        System.out.println("Invalid!");
                }
            } catch (CustomerNotFoundException | ProductNotFoundException | OrderNotFoundException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
