package com.java.main;

public class Main {
    public static void main(String[] args) {
        EcomApp.main(args);
    }
}