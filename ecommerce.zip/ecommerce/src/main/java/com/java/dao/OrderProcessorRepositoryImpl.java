package com.java.dao;
import com.java.entity.*;
import com.java.exceptions.*;
import com.java.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;


public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {

    @Override
    public boolean createProduct(Products product) {
        try (Connection conn = DBConnection.getConnect()){
            String query = "INSERT INTO products (product_id,name, price, description, stock_quantity) VALUES (?,?, ?, ?, ?)";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, product.getProductId());
            stat.setString(2, product.getName());
            stat.setDouble(3, product.getPrice());
            stat.setString(4, product.getDescription());
            stat.setInt(5, product.getStockQuantity());
            int rows = stat.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
        	System.out.println(e);
            return false;
        }
    }

    @Override
   /* public boolean createCustomer(Customers customer) {
        try (Connection conn = DBConnection.getConnect()) {
            String query = "INSERT INTO customers (customer_id,name, email, password) VALUES (?,?, ?, ?)";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, customer.getCustomerId());
            stat.setString(2, customer.getName());
            stat.setString(3, customer.getEmail());
            stat.setString(4, customer.getPassword());
            int rows = stat.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
        	System.out.println(e);
            return false;
        }
    }*/
    public boolean createCustomer(Customers customer) {
        try (Connection conn= DBConnection.getConnect()) {
            int customerId = generateCustomerId(conn);

            String query = "INSERT INTO customers (customer_id, name, email, password) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stat = conn.prepareStatement(query)) {
                stat.setInt(1, customerId);
                stat.setString(2, customer.getName());
                stat.setString(3, customer.getEmail());
                stat.setString(4, customer.getPassword());
                int rowsAffected = stat.executeUpdate();
                customer.setCustomerId(customerId);
                return rowsAffected > 0;
            }
        } catch (Exception e) {
           System.out.println(e);
            return false;
        }
    }

    private int generateCustomerId(Connection conn) throws SQLException {
        String getMaxIdQuery = "SELECT MAX(customer_id) FROM customers";
        try (PreparedStatement getMaxId = conn.prepareStatement(getMaxIdQuery)) {
            ResultSet rs = getMaxId.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) + 1;
            } else {
                return 1; 
            }
        }
    }

    @Override
    public boolean deleteProduct(int productId) {
        try (Connection connection = DBConnection.getConnect()) {
            connection.setAutoCommit(false);
            String deleteFromCartQuery = "DELETE FROM cart WHERE product_id = ?";
            try (PreparedStatement stat = connection.prepareStatement(deleteFromCartQuery)) {
                stat.setInt(1, productId);
                stat.executeUpdate();
            }
            String deleteFromOrderItemsQuery = "DELETE FROM order_items WHERE product_id = ?";
            try (PreparedStatement stat = connection.prepareStatement(deleteFromOrderItemsQuery)) {
                stat.setInt(1, productId);
                stat.executeUpdate();
            }
            String deleteProductQuery = "DELETE FROM products WHERE product_id = ?";
            try (PreparedStatement stat = connection.prepareStatement(deleteProductQuery)) {
                stat.setInt(1, productId);
                int rowsAffected = stat.executeUpdate();
                connection.commit();
                return rowsAffected > 0;
            } catch (Exception e) {
                connection.rollback();
                System.out.println(e);
                return false;
            }
        } catch (Exception e) {
        	 System.out.println(e);
            return false;
        }
    }


    @Override
    public boolean deleteCustomer(int customerId) {
        try (Connection conn = DBConnection.getConnect()) {
            String query = "DELETE FROM customers WHERE customer_id = ?";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, customerId);
            int rows = stat.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
        	System.out.println(e);
            return false;
        }
    }

    @Override
    public boolean addToCart(Customers customer, Products product, int quantity) {
        try (Connection connection = DBConnection.getConnect()) {
            int maxCartId = getMaxCartId(connection);// to generate new cart_id at the time of adding product to cart
            int newCartId = maxCartId + 1;

            String addToCartQuery = "INSERT INTO cart (cart_id, customer_id, product_id, quantity) VALUES (?, ?, ?, ?)";
            try (PreparedStatement addToCartStatement = connection.prepareStatement(addToCartQuery)) {
                addToCartStatement.setInt(1, newCartId);
                addToCartStatement.setInt(2, customer.getCustomerId());
                addToCartStatement.setInt(3, product.getProductId());
                addToCartStatement.setInt(4, quantity);
                addToCartStatement.executeUpdate();
                return true;
            }
        } catch (Exception e) {
        	System.out.println(e);
            return false;
        }
    }

    private int getMaxCartId(Connection connection) throws SQLException {
        String getMaxCartIdQuery = "SELECT MAX(cart_id) FROM cart";
        try (PreparedStatement getMaxCartIdStatement = connection.prepareStatement(getMaxCartIdQuery)) {
            ResultSet rs = getMaxCartIdStatement.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                return 0; 
            }
        }
    }


    
    
    @Override
    public boolean removeFromCart(Customers customer, Products product) {
        try (Connection conn = DBConnection.getConnect()) {
            String query = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, customer.getCustomerId());
            stat.setInt(2, product.getProductId());
            int rows = stat.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
        	System.out.println(e);
            return false;
        }
    }

    @Override
    public List<Products> getAllFromCart(Customers customer) {
        List<Products> productList = new ArrayList<>();
        try (Connection conn = DBConnection.getConnect()) {
            String query = "SELECT p.* FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.customer_id = ?";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, customer.getCustomerId());
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Products product = new Products();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setStockQuantity(rs.getInt("stock_quantity"));
                productList.add(product);
            }
        } catch (Exception e) {
        	System.out.println(e);
        }
        return productList;
    }

    @Override
    /* public boolean placeOrder(Customers customer, List<Map<Products, Integer>> cartItems, String shippingAddress) {
        try (Connection conn = DBConnection.getConnect()) {
        	 int maxOrderId = getMaxOrderId(conn);// to generate new order_id at the time of adding product to cart
             int newOrderId = maxOrderId + 1;

            String orderQuery = "INSERT INTO orders (customer_id,shipping_address) VALUES (?, ?)";
            PreparedStatement stat = conn.prepareStatement(orderQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            stat.setInt(1, customer.getCustomerId());
            stat.setString(2, shippingAddress);
            stat.executeUpdate();
            return true;
        } 
        catch (Exception e) {
        	System.out.println(e);
            return false;
        }
    }
    private int getMaxOrderId(Connection conn) throws SQLException {
        String getMaxCartIdQuery = "SELECT MAX(cart_id) FROM cart";
        try (PreparedStatement stmt = conn.prepareStatement(getMaxCartIdQuery)) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                return 0; 
            }
        }
    }
*/
    public boolean placeOrder(Customers customer, List<Map<Products, Integer>> cartItems, String shippingAddress) {
    try (Connection conn = DBConnection.getConnect()) {
        conn.setAutoCommit(false);
        int orderId = generateOrderId(conn);

        String orderQuery = "INSERT INTO orders (order_id, customer_id, order_date, total_price, shipping_address) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stat = conn.prepareStatement(orderQuery)) {
            stat.setInt(1, orderId);
            stat.setInt(2, customer.getCustomerId());
            stat.setDate(3, new java.sql.Date(System.currentTimeMillis()));
            stat.setDouble(4, calculateTotalPrice(cartItems));
            stat.setString(5, shippingAddress);
            stat.executeUpdate();

            String orderItemQuery = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(orderItemQuery)) {
                for (Map<Products, Integer> item : cartItems) {
                    for (Map.Entry<Products, Integer> entry : item.entrySet()) {
                        stmt.setInt(1, orderId);
                        stmt.setInt(2, entry.getKey().getProductId());
                        stmt.setInt(3, entry.getValue());
                        stmt.addBatch();
                    }
                }
                stmt.executeBatch();
            }

            conn.commit();
            return true;
        } catch (Exception e) {
            conn.rollback();
           System.out.println(e);
            return false;
        }
    } catch (Exception e) {
    	 System.out.println(e);
        return false;
    }
}

private int generateOrderId(Connection conn) throws SQLException {
    String getMaxIdQuery = "SELECT MAX(order_id) FROM orders";
    try (PreparedStatement getId = conn.prepareStatement(getMaxIdQuery)) {
        ResultSet rs = getId.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) + 1;
        } else {
            return 1; 
        }
    }
}



    private double calculateTotalPrice(List<Map<Products, Integer>> cartItems) {
        double total = 0;
        for (Map<Products, Integer> item : cartItems) {
            for (Map.Entry<Products, Integer> entry : item.entrySet()) {
                total += entry.getKey().getPrice() * entry.getValue();
            }
        }
        return total;
    }

    @Override
    public List<Orders> getOrdersByCustomer(int customerId) {
        List<Orders> orderList = new ArrayList<>();
        try (Connection conn = DBConnection.getConnect()) {
            String query = "SELECT * FROM orders WHERE customer_id = ?";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, customerId);
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Orders order = new Orders();
                order.setOrderId(rs.getInt("order_id"));
                order.setCustomerId(rs.getInt("customer_id"));
                order.setOrderDate(rs.getDate("order_date"));
                order.setTotalPrice(rs.getDouble("total_price"));
                order.setShippingAddress(rs.getString("shipping_address"));
                orderList.add(order);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return orderList;
    }
}
