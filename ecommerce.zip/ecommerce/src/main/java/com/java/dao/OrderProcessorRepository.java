package com.java.dao;
import java.util.List;
import java.util.Map;
import com.java.entity.*;

public interface OrderProcessorRepository {
    boolean createProduct(Products product);
    boolean createCustomer(Customers customer);
    boolean deleteProduct(int productId);
    boolean deleteCustomer(int customerId);
    boolean addToCart(Customers customer, Products product, int quantity);
    boolean removeFromCart(Customers customer, Products product);
    List<Products> getAllFromCart(Customers customer);
    boolean placeOrder(Customers customer, List<Map<Products, Integer>> cartItems, String shippingAddress);
    List<Orders> getOrdersByCustomer(int customerId);
}

