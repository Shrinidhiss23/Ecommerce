package com.java.service;
import com.java.dao.*;
import com.java.entity.*;
import com.java.exceptions.*;
import java.util.List;
import java.util.Map;

public class Service {
    private final OrderProcessorRepositoryImpl op;

    public Service() {
        this.op = new OrderProcessorRepositoryImpl();
    }

    public boolean addCustomer(Customers customer) {
        return op.createCustomer(customer);
    }

    public boolean addProduct(Products product) {
        return op.createProduct(product);
    }

    public boolean deleteProduct(int productId) {
        return op.deleteProduct(productId);
    }

    public boolean addToCart(Customers customer, Products product, int quantity) {
        return op.addToCart(customer, product, quantity);
    }

    public boolean removeFromCart(Customers customer, Products product) {
        return op.removeFromCart(customer, product);
    }

    public List<Products> getAllFromCart(Customers customer) {
        return op.getAllFromCart(customer);
    }

    public boolean placeOrder(Customers customer, List<Map<Products, Integer>> cartItems, String shippingAddress) {
        return op.placeOrder(customer, cartItems, shippingAddress);
    }
    


    public double calculateTotalPrice(List<Map<Products, Integer>> cartItems) throws ProductNotFoundException {
        double totalPrice = 0;
        for (Map<Products, Integer> item : cartItems) {
            for (Map.Entry<Products, Integer> entry : item.entrySet()) {
                Products product = entry.getKey();
                int quantity = entry.getValue();
                double price = product.getPrice();
                totalPrice += price * quantity;
            }
        }
        return totalPrice;
    }
 
}
