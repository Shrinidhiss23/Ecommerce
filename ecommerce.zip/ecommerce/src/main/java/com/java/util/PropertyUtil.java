package com.java.util;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtil {
    public static String getPropertyString(String propertyFileName) {
        Properties properties = new Properties();
        try (FileInputStream inputStream = new FileInputStream(propertyFileName)) {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "jdbc:mysql://" + properties.getProperty("localhost") + ":" + properties.getProperty("3360") + "/" + properties.getProperty("Ecommerce") +
               "?user=" + properties.getProperty("root") + "&password=" + properties.getProperty("Shrinidhi@sql24");
    }
}

