package Dao;
import com.java.dao.*;
import com.java.entity.*;
import com.java.service.Service;

import org.junit.jupiter.api.*;
import com.java.util.*;
import java.sql.Connection;
import java.sql.Statement;
import static org.junit.jupiter.api.Assertions.*;

public class OrderProcessorRepositoryImplTest {
    private OrderProcessorRepositoryImpl opr;

    @BeforeEach
    public void setUp() {
        opr = new OrderProcessorRepositoryImpl();
    }

    @AfterEach
    public void tearDown() {
        try (Connection conn = DBConnection.getConnect()) {
            Statement stat = conn.createStatement();
            stat.executeUpdate("TRUNCATE TABLE customers");
            stat.executeUpdate("TRUNCATE TABLE products");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Test
    public void testCreateCustomer() {
        Customers customer = new Customers("Johny Depp", "john@example.com", "password123");
        assertTrue(opr.createCustomer(customer));
         assertTrue(customer.getCustomerId() > 0);
    }
   
   /* public class CustomerServiceTest {
        @Test
        public void testCreateCustomer() {
            Service s = new Service();
            Customers customer = new Customers();
            customer.setName("Johny Depp");
            customer.setEmail("john.doe@example.com");
            customer.setPassword("password123");

            boolean result = Service.createCustomer(customer);

            assertTrue(result);
            assertTrue(customer.getCustomerId() > 0);
        }
    }
    */

    @Test
    public void testCreateProduct() {
        Products product = new Products("Laptop", 999.99, "High-end gaming laptop", 10);
        assertTrue(opr.createProduct(product));
    }

    @Test
    public void testDeleteProduct() {
        Products product = new Products("Laptop", 999.99, "High-end gaming laptop", 10);
        opr.createProduct(product);
        assertTrue(opr.deleteProduct(product.getProductId()));
    }

    @Test
    public void testDeleteCustomer() {
        Customers customer = new Customers("Johny Depp", "john@example.com", "password123");
        opr.createCustomer(customer);
        assertTrue(opr.deleteCustomer(customer.getCustomerId()));
    }

    @Test
    public void testAddToCart() {
        Customers customer = new Customers("Johny Depp", "john@example.com", "password123");
        opr.createCustomer(customer);
        Products product = new Products("Laptop", 999.99, "High-end gaming laptop", 10);
      opr.createProduct(product);
        assertTrue(opr.addToCart(customer, product, 1));
    }

    @Test
    public void testRemoveFromCart() {
        Customers customer = new Customers("Johny Depp", "john@example.com", "password123");
        opr.createCustomer(customer);
        Products product = new Products("Laptop", 999.99, "High-end gaming laptop", 10);
        opr.createProduct(product);
        opr.addToCart(customer, product, 1);
        assertTrue(opr.removeFromCart(customer, product));
    }

    @Test
    public void testGetAllFromCart() {
        Customers customer = new Customers("Johny Depp", "john@example.com", "password123");
        opr.createCustomer(customer);
        Products product1 = new Products("Laptop", 999.99, "High-end gaming laptop", 10);
        Products product2 = new Products("Mouse", 19.99, "Wireless mouse", 100);
        opr.createProduct(product1);
        opr.createProduct(product2);
        opr.addToCart(customer, product1, 1);
        opr.addToCart(customer, product2, 2);
        assertEquals(2, opr.getAllFromCart(customer).size());
    }
}

